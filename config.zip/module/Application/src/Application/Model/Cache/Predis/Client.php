<?php
	namespace Application\Model\Cache\Predis;

	use 
		Predis\Client as PClient,
		Zend\Db\TableGateway\TableGateway;
	/**
	 * Description of Client
	 *
	 * @author sirvantos
	 */
	final class Client extends PClient
	{
		const TEMPLATE_TAGS		= '%{VALUE}%';
		const TEMPLATE_TYPE		= '|{VALUE}|';
		const TEMPLATE_KEY		= '&{VALUE}&';
		
		const DEFAULT_EXPIRE	= 3600;
		
		const KEY_TYPE_LIST		= 1;
		
		private $defaultExpire  = self::DEFAULT_EXPIRE;
		
		/**
		 * @var TableGateway 
		 */
		private $tableGetway = null;
		
		/**
		* Initializes a new client with optional connection parameters and client options.
		*
		* @param mixed $parameters Connection parameters for one or multiple servers.
		* @param mixed $options Options that specify certain behaviours for the client.
		*/
		public function __construct($parameters = null, $options = null)
		{
			parent::__construct($parameters, $options);
			
			if (!empty($parameters['default_expire'])) 
			{
				$this->defaultExpire = $parameters['default_expire'];
			}
		}
		
		/**
		 * @param TableGateway
		 * @return Client
		 */
		public function setTableGetway(TableGateway $tg)
		{
			$this->tableGetway = $tg;
			
			return $this;
		}
		
		/**
		 * @param String $key
		 * @return null | Array
		 */
		public function getListFromCache($key)
		{
			$cacheKey = $this->makeListCachePrefix($key);
			
			if ($keys = $this->getKeysByKey($cacheKey)) {
				
				$result = array();
				
				foreach ($keys as $listKey) {
					$result[] = $this->hgetall($cacheKey . $listKey);
				}
				
				return $result;
			}
			
			return null;
		}
		
		/**
		 * @param String $key
		 * @param array $list
		 * @param Int | null $expire
		 * @return Client
		 */
		public function setList2Cache(
			$key, Array $list, $expire = self::DEFAULT_EXPIRE
		)
		{
			if (!$list) return array();
			
			$hashKey	= $this->makeListCachePrefix($key);
			
			$this->del($hashKey);
			
			foreach ($list as $row) 
			{
				$hashKeyId	= $hashKey . $row['id'];
				
				if ($this->exists($hashKeyId)) $this->del($hashKeyId);
				
				$this->sadd($hashKey, $row['id']);
				$this->hmset($hashKeyId, $row);
			}
			
			if ($expire) { 
				$this->setExpire ($hashKey, $expire);
				$this->setExpire ($hashKeyId, $expire);
			}
			
			return $this;
		}
		
		/**
		 * @param String $key
		 * @return boolean
		 */
		public function removeListFrom($key)
		{
			if ($keys = $this->getKeysByKey($this->makeListCachePrefix($key))) {
				$result = array();
				
				foreach ($keys as $listKey) {
					$this->del($listKey);
				}
				
				return true;
			}
			
			return false;
		}
		
		/**
		 * @param Integer $key
		 * @param String $expire
		 * @return Client
		 * @throws \Zend\Barcode\Object\Exception\RuntimeException
		 */
		public function setExpire(/*String*/ $key, /*Int*/ $expire = null)
		{
			if ($expire === null) $expire = $this->defaultExpire;
			
			if (is_string($expire)) $expire = strtotime($expire) - time();
			
			if (!is_int($expire)) {
				throw new \Zend\Barcode\Object\Exception\RuntimeException(
					'Wrong expire given >>' . $expire . '<<'
				);
			}
			
			$this->expire($key, $expire);
			
			return $this;
		}
		
		/**
		 * @param String $key
		 * @return Array
		 */
		private function getKeysByKey($cacheKey)
		{
			return $this->smembers($cacheKey);
		}
		
		/**
		 * @param String $keyName
		 * @return String
		 */
		private function makeCacheKey($keyName, $type = self::KEY_TYPE_LIST)
		{
			//table prefix
			$key = md5(strtolower($this->tableGetway->getTable()));
			
			switch ($type) {
				case self::KEY_TYPE_LIST:
				default:
					$key .= str_replace('{VALUE}', 'list', self::TEMPLATE_TYPE);
			}
			
			return $key;
		}
		
		/**
		 * @param String $keyName
		 * @return String
		 */
		private function makeListCachePrefix($keyName, array $tags = array())
		{
			return $this->makeCacheKey($keyName, $tags);
		}
	}
?>
